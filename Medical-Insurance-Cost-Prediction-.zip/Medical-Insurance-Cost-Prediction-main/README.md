# Medical-Insurance-Cost-Prediction
A project that analyses the data of patients and predict the cost of medical insurance paying by them by evaluating the model based on different performance metrics. 

Demonstartion Vedio Link : https://drive.google.com/file/d/1CTiTiFp56HwKxrfVMab_ZAJ0_XCj-aPr/view?usp=sharing
